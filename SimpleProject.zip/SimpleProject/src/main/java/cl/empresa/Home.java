package cl.empresa;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Home
 */
@WebServlet("/Home")
public class Home extends HttpServlet {
	private static final long serialVersionUID = 1L;
    mostrarPantalla pantalla = new mostrarPantalla();
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		String nom = request.getParameter("nombre");
		String ap = request.getParameter("apellido");
		String len = request.getParameter("lenguaje");
		String ciu = request.getParameter("ciudad");
		pantalla.setNombre(nom);
		pantalla.setApellido(ap);
		pantalla.setLenguaje(len);
		pantalla.setCiudad(ciu);
		PrintWriter pw = response.getWriter();
		pw.println(pantalla.mensaje());
		
	}

}
