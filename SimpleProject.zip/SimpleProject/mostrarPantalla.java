package cl.empresa;

public class mostrarPantalla {
	String nombre;
	String apellido;
	String lenguaje;
	String ciudad;
	
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public String getLenguaje() {
		return lenguaje;
	}
	public void setLenguaje(String lenguaje) {
		this.lenguaje = lenguaje;
	}
	public String getCiudad() {
		return ciudad;
	}
	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}
	
	public String mensaje(){
		if (nombre == null) {
			nombre = "Unknown";
		}
		if (apellido == null) {
			apellido = "Unknown";
		}
		if (ciudad == null) {
			ciudad = "Unknown";
		}
		if (lenguaje == null) {
			lenguaje = "Unknown";
		}
		return "<h1>Welcome, "+nombre+" "+apellido+"</h1>"+"<h2>Your favorite language is: "+lenguaje+"</h2>"+"<h2>Your hometown is: "+ciudad+"</h2>";
	}
	
}
