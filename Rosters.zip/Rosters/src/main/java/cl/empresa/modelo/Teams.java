package cl.empresa.modelo;

import java.util.ArrayList;

public class Teams {
	private String nombreEquipo;
	private ArrayList<Player>listaJugadores;
		
	public Teams() {
		super();
	}

	public Teams(String nombreEquipo, ArrayList<Player> listaJugadores) {
		super();
		this.nombreEquipo = nombreEquipo;
		this.listaJugadores = listaJugadores;
	}

	public String getNombreEquipo() {
		return nombreEquipo;
	}

	public void setNombreEquipo(String nombreEquipo) {
		this.nombreEquipo = nombreEquipo;
	}

	public ArrayList<Player> getListaJugadores() {
		return listaJugadores;
	}

	public void setListaJugadores(ArrayList<Player> listaJugadores) {
		this.listaJugadores = listaJugadores;
	}

	@Override
	public String toString() {
		return "Teams [nombreEquipo=" + nombreEquipo + ", listaJugadores=" + listaJugadores + "]";
	}
	
}
