package cl.empresa.modelo;

import java.util.ArrayList;

public class Roster {
	private ArrayList<Teams>listaEquipos;
	
	public Roster() {
		super();
	}

	public Roster(ArrayList<Teams> listaEquipos) {
		super();
		this.listaEquipos = listaEquipos;
	}

	public ArrayList<Teams> getListaEquipos() {
		return listaEquipos;
	}

	public void setListaEquipos(ArrayList<Teams> listaEquipos) {
		this.listaEquipos = listaEquipos;
	}

	@Override
	public String toString() {
		return "Roster [listaEquipos=" + listaEquipos + "]";
	}
	
}
