package cl.empresa.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cl.empresa.modelo.Player;
import cl.empresa.modelo.Roster;
import cl.empresa.modelo.Teams;

/**
 * Servlet implementation class EliminaJugador
 */
@WebServlet("/EliminaJugador")
public class EliminaJugador extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int indice = Integer.parseInt(request.getParameter("id"));
		int indiceTeam = Integer.parseInt(request.getParameter("teamid"));
		
		//Obtener lista de estantes de la Bibilioteca
		HttpSession sesion = request.getSession();
		Roster listaTotal = (Roster) sesion.getAttribute("biblioteca");
		ArrayList<Teams> listaEstantes = listaTotal.getListaEquipos();
		
		//Obtener el estante con el id dado
		Teams Equipo = listaEstantes.get(indiceTeam);
		ArrayList<Player> listaLibros = Equipo.getListaJugadores();
		
		//Remover el libro
		listaLibros.remove(indiceTeam);
		sesion.setAttribute("biblioteca", listaTotal);

		response.sendRedirect("Home");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
