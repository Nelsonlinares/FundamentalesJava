package cl.empresa.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cl.empresa.modelo.Player;
import cl.empresa.modelo.Roster;
import cl.empresa.modelo.Teams;


@WebServlet("/ManejaTeams")
public class ManejaTeams extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession sesion = request.getSession();
		
		int numeroIndice = Integer.parseInt(request.getParameter("id"));
		
		Roster listaTotal = (Roster) sesion.getAttribute("roster");
		ArrayList<Teams> listaT = listaTotal.getListaEquipos();
		Teams team = listaT.get(numeroIndice);
		
		request.setAttribute("team", team);
		request.setAttribute("indice", numeroIndice);
		RequestDispatcher rd = request.getRequestDispatcher("ListaTeams.jsp");
		rd.forward(request, response);
	}
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession sesion = request.getSession();
		String nombreTeam = request.getParameter("nombreE");
		ArrayList<Player> listaJugadores = new ArrayList<Player>();
		
		Teams nuevoTeam = new Teams(nombreTeam,listaJugadores);
	
		Roster listaTotal = (Roster) sesion.getAttribute("roster");
		ArrayList<Teams> listaEquipo = new ArrayList<Teams>();
		System.out.println(listaTotal);
		listaEquipo = listaTotal.getListaEquipos();
		listaEquipo.add(nuevoTeam);
		
		sesion.setAttribute("roster", listaTotal);
		response.sendRedirect("ManejaRoster");
	}

}
