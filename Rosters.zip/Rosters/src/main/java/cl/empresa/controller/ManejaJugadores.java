package cl.empresa.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cl.empresa.modelo.Player;
import cl.empresa.modelo.Roster;
import cl.empresa.modelo.Teams;

/**
 * Servlet implementation class ManejaJugadores
 */
@WebServlet("/ManejaJugadores")
public class ManejaJugadores extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession sesion = request.getSession();
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String first_name = request.getParameter("nombreP");
		String last_name = request.getParameter("apellidoP");
		int age = Integer.parseInt(request.getParameter("age"));
		Player nuevoPlayer = new Player(first_name,last_name,age);
		
		
		int indice = Integer.parseInt(request.getParameter("id"));
		
		HttpSession sesion = request.getSession();
		Roster listaTotal = (Roster) sesion.getAttribute("biblioteca");
		
		ArrayList<Teams> listaTeams = listaTotal.getListaEquipos();
		
		Teams Equipo = listaTeams.get(indice);
		
		
		ArrayList<Player> listaJugador = Equipo.getListaJugadores();
		listaJugador.add(nuevoPlayer);
		
		sesion.setAttribute("biblioteca", listaTotal);
			
		response.sendRedirect("Home");
		
	}

}
