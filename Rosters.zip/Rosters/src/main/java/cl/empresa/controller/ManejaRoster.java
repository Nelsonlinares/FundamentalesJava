package cl.empresa.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cl.empresa.modelo.Roster;
import cl.empresa.modelo.Teams;

@WebServlet("/ManejaRoster")
public class ManejaRoster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession sesion = request.getSession();
		Roster listaTotal = (Roster) sesion.getAttribute("roster");
		
		if(sesion.getAttribute("roster") == null) {
			ArrayList<Teams> elemento = new ArrayList<Teams>();
			listaTotal = new Roster(elemento);
		}
		
		sesion.setAttribute("roster", listaTotal);
		System.out.println(listaTotal);
		RequestDispatcher rd = request.getRequestDispatcher("Home.jsp");
		rd.forward(request, response);
	}


}
