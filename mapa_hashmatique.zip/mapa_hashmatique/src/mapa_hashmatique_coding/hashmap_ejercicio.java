package mapa_hashmatique_coding;

import java.util.HashMap;

public class hashmap_ejercicio {
	public static void main(String[] args) {
		// Crear un trackList de tipo HashMap.
		
		HashMap<String, String> tracklist = new HashMap<String, String>();
		
		//Agregar al menos 4 canciones que est�n almacenadas por t�tulo.
		tracklist.put("La Melod�a","Estamos aqu� reunidos practicando programaci�n, vamos somos los estudiantes lideres de Chile");
		tracklist.put("Canci�n favorita","El coding dojo es la mejor plataforma de aprendizaje del momento y nos va a permitir ser excelentes progrmadores del ma�ana");
		tracklist.put("Vamos a descansar","La jornada del d�a ha estado intensa, vamos a preparar un descanso para despejar la mente un poco, luego continuaremos");
		tracklist.put("Despedida","Nos despedimos por hoy, hemos aprendido much�simo en la semana y seguiremos aprendiendo este fin de semana, nos vemos el lunes");
		
		//Extraer una canci�n por su t�tulo.
		System.out.println(tracklist.get("La Melod�a"));
		
		//Imprimir todos los nombres de las pistas y las letras en un formato Track: Lyrics.
		for (String result : tracklist.keySet()) {
			System.out.println("Track:"+result+" -> Lyrics:"+ tracklist.get(result));
		
	}

	}
}