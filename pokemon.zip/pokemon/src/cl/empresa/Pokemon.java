package cl.empresa;

public class Pokemon implements PkemonInt{
	private String name;
	private int health;
	private String type;
	public static int contador = 0;
	
	public Pokemon() {
		super();
		contador++;
	}

	public Pokemon(String name, int health, String type) {
		super();
		this.name = name;
		this.health = health;
		this.type = type;
		contador++;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getHealth() {
		return health;
	}


	public void setHealth(int health) {
		this.health = health;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	void attackPokemon(Pokemon pokemonAtacado) {
		pokemonAtacado.setHealth(pokemonAtacado.health -10);
	}
	

	@Override
	public String toString() {
		return "Pokemon [name=" + name + ", health=" + health + ", type=" + type + "]";
	}

	@Override
	public Pokemon createPokemon(String name, int health, String type) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String pokemonInfo(Pokemon pokemon) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void listPokemon() {
		// TODO Auto-generated method stub
	}

	
}
