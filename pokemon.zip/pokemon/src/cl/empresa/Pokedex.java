package cl.empresa;

import java.util.ArrayList;

public class Pokedex extends PokemonAbstracta{
	public static ArrayList<Pokemon> myPokemons = new ArrayList<Pokemon>();
	
	public void listPokemon(){
		System.out.println(myPokemons);
	}
}
