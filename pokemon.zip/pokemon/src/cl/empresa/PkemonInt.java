package cl.empresa;

public interface PkemonInt {
	Pokemon createPokemon(String name, int health, String type);

	String pokemonInfo(Pokemon pokemon);
	
	void listPokemon();
}
