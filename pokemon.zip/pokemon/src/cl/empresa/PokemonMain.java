package cl.empresa;

public class PokemonMain {

	public static void main(String[] args) {
	Pokedex poke = new Pokedex();
	poke.createPokemon("pikachu",100,"El�ctrico");
	poke.createPokemon("bulbasaur",100,"Tierra");
	poke.listPokemon();
	Pokemon poke1 = Pokedex.myPokemons.get(0);
	Pokemon poke2 = Pokedex.myPokemons.get(1);
	poke1.attackPokemon(poke2);
	poke.listPokemon();
	}

}
