package cl.empresa;

public abstract class PokemonAbstracta implements PkemonInt{
	public Pokemon createPokemon(String name, int health, String type){
		Pokemon pokemon = new Pokemon(name, health, type);
		Pokedex.myPokemons.add(pokemon);
		Pokemon.contador++;
		return pokemon;
	}
	public String pokemonInfo(Pokemon pokemon) {
		return "El nombre del pokemon es: "+pokemon.getName()+", su salud es: "+pokemon.getHealth()+", y es de tipo: "+pokemon.getType();
	}
	
}
