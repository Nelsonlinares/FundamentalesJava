package cl.empresa;

import cl.empresa.modelo.Human;
import cl.empresa.modelo.Ninja;
import cl.empresa.modelo.Samurai;
import cl.empresa.modelo.Wizard;

public class HumanTest {
	public static void main(String[] args) {
		Human h1 = new Human();
		Human h2 = new Human();
		
		//Prueba de m�todos de la parte 1 del ejercicio
		h1.attack(h2);
		System.out.println(h2.getHealth());
		
		Wizard w1 = new Wizard();
		Samurai s1 = new Samurai();
		Ninja n1 = new Ninja();
		
		//Prueba de m�todos de la parte 1 del ejercicio
		w1.heal(h2);
		System.out.println(h2.getHealth());
		
		n1.steal(h2);
		System.out.println(h2.getHealth());
		System.out.println(n1.getHealth());
		
		n1.runAway();
		System.out.println(n1.getHealth());
		
		s1.deathBlow(h1);
		System.out.println(h1.getHealth());
		System.out.println(s1.getHealth());
		s1.meditate();
		System.out.println(s1.getHealth());
		s1.howMany();
		
	}
}
