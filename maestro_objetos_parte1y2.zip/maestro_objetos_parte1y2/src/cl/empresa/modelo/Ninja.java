package cl.empresa.modelo;

public class Ninja extends Human{
	private int strength = 3;
	private int intelligence = 8;
	private int stealth = 10; //Ninja: Establecer un valor predeterminado de stealth en 10.
	private int health = 50;
		
	public Ninja() {
		super();
	}

	public Ninja(int strength, int intelligence, int stealth, int health) {
		super();
		this.strength = strength;
		this.intelligence = intelligence;
		this.stealth = stealth;
		this.health = health;
	}

	public int getStrength() {
		return strength;
	}

	public void setStrength(int strength) {
		this.strength = strength;
	}

	public int getIntelligence() {
		return intelligence;
	}

	public void setIntelligence(int intelligence) {
		this.intelligence = intelligence;
	}

	public int getStealth() {
		return stealth;
	}

	public void setStealth(int stealth) {
		this.stealth = stealth;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	@Override
	public String toString() {
		return "Ninja [strength=" + strength + ", intelligence=" + intelligence + ", stealth=" + stealth + ", health="
				+ health + "]";
	}
	
	//Ninja: Agregar un m�todo steal(Human) que roba la cantidad de puntos que tenga el Ninja en stealth de la salud del otro Human y los agrega a la health del Ninja.
	public void steal(Human humanoRobado) {
		humanoRobado.setHealth(humanoRobado.getHealth()-this.stealth);
		this.health += this.stealth;
			}
	
	//Ninja: Agregar un m�todo runAway() que reduce su salud en 10.
	public void runAway() {
		setHealth(health-10);
	}
	
}
