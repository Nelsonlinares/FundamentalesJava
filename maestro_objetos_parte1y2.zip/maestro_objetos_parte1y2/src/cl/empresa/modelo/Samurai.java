package cl.empresa.modelo;

public class Samurai extends Human{
	private int strength = 3;
	private int intelligence = 8;
	private int stealth = 10;
	private int health = 200; //Samurai: Establecer un valor predeterminado de health en 200.
	
	public int cuantosSamurai = 0;
	
	public Samurai() {
		super();
		cuantosSamurai = cuantosSamurai + 1;
	}

	public Samurai(int strength, int intelligence, int stealth, int health) {
		super();
		this.strength = strength;
		this.intelligence = intelligence;
		this.stealth = stealth;
		this.health = health;
		cuantosSamurai = cuantosSamurai + 1;
	}

	public int getStrength() {
		return strength;
	}

	public void setStrength(int strength) {
		this.strength = strength;
	}

	public int getIntelligence() {
		return intelligence;
	}

	public void setIntelligence(int intelligence) {
		this.intelligence = intelligence;
	}

	public int getStealth() {
		return stealth;
	}

	public void setStealth(int stealth) {
		this.stealth = stealth;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	@Override
	public String toString() {
		return "Samurai [strength=" + strength + ", intelligence=" + intelligence + ", stealth=" + stealth + ", health="
				+ health + "]";
	}
		
	//Samurai: Agregar un m�todo deathBlow(Human) que asesina al otro Human y reduce la health del Samurai a la mitad.
	public void deathBlow(Human humanoAsesinado) {
		humanoAsesinado.setHealth(0);
		setHealth(health/2);
	}
	
	//Samurai: Agregar un m�todo meditate() que curar� al Samurai en la mitad de puntos que tenga de health.
	public void meditate() {
		setHealth(health+(health/2));
	}
	
	//Samurai: Agregar un m�todo howMany() que devuelve el n�mero actual del Samurai.
	public void howMany() {
		System.out.println(cuantosSamurai);
	}
}
