package cl.empresa.modelo;

public class Wizard extends Human{
	private int strength = 3;
	private int intelligence = 8; //Wizard: Establecer un valor predeterminado de intelligence en 8.
	private int stealth = 3;
	private int health = 50; //Wizard: Establecer un valor predeterminado de healt en 50.
	

	public Wizard() {
		super();
	}

	
	public Wizard(int strength, int intelligence, int stealth, int health) {
		super();
		this.strength = strength;
		this.intelligence = intelligence;
		this.stealth = stealth;
		this.health = health;
	}


	public int getStrength() {
		return strength;
	}

	public void setStrength(int strength) {
		this.strength = strength;
	}

	public int getIntelligence() {
		return intelligence;
	}

	public void setIntelligence(int intelligence) {
		this.intelligence = intelligence;
	}

	public int getStealth() {
		return stealth;
	}

	public void setStealth(int stealth) {
		this.stealth = stealth;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	@Override
	public String toString() {
		return "Wizard [strength=" + strength + ", intelligence=" + intelligence + ", stealth=" + stealth + ", health="
				+ health + "]";
	}
	
	// Wizard: Agregar un m�todo heal(Human) que aumentar� la salud del otro Human en los puntos de intelligence que tenga el Wizard.
	public void heal(Human humanoSanado) {
		humanoSanado.setHealth(humanoSanado.getHealth()+this.getIntelligence());
	}
	
	//Wizard: Agregar un m�todo fireBall(Human) que disminuye la salud del otro Human en los puntos de intelligence * 3 que tenga el Wizard.
	public void fireball(Human humanoAtacado) {
		humanoAtacado.setHealth(humanoAtacado.getHealth()-(this.getIntelligence()*3));
	}
	
	
	
}
