package cl.empresa.modelo;

public class Dog extends Animal implements Pet {
	
	public Dog() {
		super();
	}

	public Dog(String nombre, String breed, int weight) {
		super(nombre, breed, weight);
	}

	@Override
	public String showAffection() {
		if (this.getWeight() < 30) {
			return this.getNombre()+" hopped into your lap and cuddled you!";
		}
		else {
			return this.getNombre()+" have them curl up next to you";
		}
	}
}
