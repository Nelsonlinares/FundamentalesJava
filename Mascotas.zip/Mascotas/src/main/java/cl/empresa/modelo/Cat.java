package cl.empresa.modelo;

public class Cat extends Animal implements Pet{
	
	public Cat() {
		super();
	}

	public Cat(String nombre, String breed, int weight) {
		super(nombre, breed, weight);
		}


	@Override
	public String showAffection() {
		return "looked at you with some affection. You think!.";
	}
	
}
