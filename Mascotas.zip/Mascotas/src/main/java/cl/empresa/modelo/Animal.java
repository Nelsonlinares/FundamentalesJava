package cl.empresa.modelo;

public abstract class Animal {
	private String nombre;
	private String breed;
	private int weight;
		
	public Animal() {
		super();
	}

	public Animal(String nombre, String breed, int weight) {
		super();
		this.nombre = nombre;
		this.breed = breed;
		this.weight = weight;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getBreed() {
		return breed;
	}

	public void setBreed(String breed) {
		this.breed = breed;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}
	
	
}
