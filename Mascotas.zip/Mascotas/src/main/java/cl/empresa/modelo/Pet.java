package cl.empresa.modelo;

public interface Pet {

	String showAffection();
}
