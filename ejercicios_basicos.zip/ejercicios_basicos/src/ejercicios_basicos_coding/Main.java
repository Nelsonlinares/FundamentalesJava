package ejercicios_basicos_coding;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		ArrayList<Integer> arreglo = new ArrayList<Integer>();
		arreglo.add(1);
		arreglo.add(3);
		arreglo.add(5);
		arreglo.add(7);
		arreglo.add(13);
		arreglo.add(9);
		
		ArrayList<Integer> arreglonegativo = new ArrayList<Integer>();
		arreglonegativo.add(1);
		arreglonegativo.add(5);
		arreglonegativo.add(10);
		arreglonegativo.add(-2);
		
		BasicJava bj = new BasicJava();
		bj.EjercicioUno();
		bj.EjercicioDos();
		bj.EjercicioTres();
		bj.EjercicioCuatro(arreglo);
		bj.EjercicioCinco(arreglo);
		bj.EjercicioSeis(arreglo);
		bj.EjercicioSiete();
		bj.EjercicioOcho(arreglo);
		bj.EjercicioNueve(arreglo);
		bj.EjercicioDiez(arreglonegativo);
		bj.EjercicioOnce(arreglo);
		bj.EjercicioDoce(arreglo);
	}	
	}

