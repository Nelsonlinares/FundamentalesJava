package ejercicios_basicos_coding;

import java.util.ArrayList;
import java.util.Scanner;

public class BasicJava {
	
	public void EjercicioUno(){for (int i = 1; i <= 255; i++) {
		System.out.print(i+ " ");
	}
		System.out.println("\n");
	}
	
	public void EjercicioDos(){for (int i = 1; i <= 255; i++) {
		if (i % 2 != 0) {
            System.out.print(i+" ");}
	}
		System.out.println("\n");
	}
	
	public void EjercicioTres(){
		int contador = 0;
		for (int i = 0; i <= 255; i++) {
			contador = contador +i;
            System.out.print("Nuevo numero: "+i+" Suma: "+contador+"\n");
	}
	}

	public void EjercicioCuatro(ArrayList<Integer> arr) {
		for (int i = 0; i < arr.size(); i++) {
		int num = arr.get(i);
		System.out.print(num+" ");
	}
		System.out.print("\n");
	}
	
	public void EjercicioCinco(ArrayList<Integer> arr) {
		int max = arr.get(0);
		for (int i = 0; i < arr.size(); i++) {
			if (arr.get(i) > max) {
				max = arr.get(i);
			}
		}
		System.out.print(max+"\n");
	}

	public void EjercicioSeis(ArrayList<Integer> arr) {
		double sum = 0;
		for (int i=0; i < arr.size(); i++) {
			sum = sum + arr.get(i);
		}
		double prom = sum/(arr.size());
		System.out.println("Promedio de "+prom);
	}
	
	public void EjercicioSiete(){
		ArrayList<Integer> y = new ArrayList<Integer>();

		{for (int i = 1; i <= 255; i++) {
	
		if (i % 2 != 0) {
            y.add(i);}
	}
		System.out.println(y);
	}
	}
	
	public void EjercicioOcho(ArrayList<Integer> arr) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Ingrese valor de y: ");
		int y = sc.nextInt();
		sc.close();
		int cont = 0;
		for (int i=0; i < arr.size(); i++) {
			if (arr.get(i)>y) {
				cont = cont + 1;	
		}
		}
		System.out.println(cont);
	}
	
	public static int cuadrado(int num){
		return (num * num);
	}
	
	public void EjercicioNueve(ArrayList<Integer> arr) {
		ArrayList<Integer> nuevoarreglo = new ArrayList<Integer>();
		for (int i = 0; i < arr.size(); i++) {
			nuevoarreglo.add(cuadrado(arr.get(i)));
		}
		System.out.println(nuevoarreglo);
	}
	
	public static int maximo(ArrayList<Integer> arr) {
		int max = arr.get(0);
		for (int i = 0; i < arr.size(); i++) {
			if (arr.get(i) > max) {
				max = arr.get(i);
			}
		}
		return (max);
	}
	
	public static int minimo(ArrayList<Integer> arr) {
		int min = arr.get(0);
		for (int i = 0; i < arr.size(); i++) {
			if (arr.get(i) < min) {
				min = arr.get(i);
			}
		}
		return (min);
	}
	
	public static int promedio(ArrayList<Integer> arr) {
		int sum = 0;
		for (int i=0; i < arr.size(); i++) {
			sum = sum + arr.get(i);
		}
		int prom = sum/(arr.size());
		return prom;
	}
	
	public void EjercicioDiez(ArrayList<Integer> arr) {
			ArrayList<Integer> nuevoarr = new ArrayList<Integer>();
			for (int i = 0; i < arr.size(); i++) {
				int numeros = arr.get(i);
				if (numeros<0) {
					nuevoarr.add(numeros*(-1));
				}
				else {
					nuevoarr.add(numeros);
				}
			System.out.println(nuevoarr);
			}
	}
	
	public void EjercicioOnce(ArrayList<Integer> arr) {
			ArrayList<Integer> nuevoarr = new ArrayList<Integer>();
			
			nuevoarr.add(maximo(arr));
			nuevoarr.add(minimo(arr));
			nuevoarr.add(promedio(arr));
		
		System.out.println(nuevoarr);
	}
	
	public void EjercicioDoce(ArrayList<Integer> arr) {
		ArrayList<Integer> nuevoarr = new ArrayList<Integer>();
		for (int i = 0; i < arr.size()-1; i++) {
			nuevoarr.add(arr.get(i+1));
		}
		nuevoarr.add(0);
		System.out.println(nuevoarr);
	}
		
}


	
