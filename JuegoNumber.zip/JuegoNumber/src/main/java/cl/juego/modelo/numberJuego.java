package cl.juego.modelo;

public class numberJuego {
	private int numeroSeteado;
	
	public numberJuego() {
		super();
	}

	public numberJuego(int numeroSeteado) {
		super();
		this.numeroSeteado = numeroSeteado;
	}

	public int getNumeroSeteado() {
		return numeroSeteado;
	}

	public void setNumeroSeteado(int numeroSeteado) {
		this.numeroSeteado = numeroSeteado;
	}

	@Override
	public String toString() {
		return "numberJuego [numeroSeteado=" + numeroSeteado + "]";
	}
	
	public static int numeroRandom() {
		int nuevoNum = (int) Math.floor(Math.random()*100);	
		System.out.println(nuevoNum);
		return nuevoNum;
		}
}
