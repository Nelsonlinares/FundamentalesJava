package cl.juego.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cl.juego.modelo.numberJuego;

@WebServlet("/ManejaNumeros")
public class ManejaNumeros extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession sesion = request.getSession();
		int numeroIngresado = Integer.parseInt(request.getParameter("numero"));
		int numeroAdivinado = 0;
		String mensajeAdivina = "";
		String mensajeMayor = "";
		String mensajeMenor = "";
		String mensajeOk = "";
		
		if (sesion.getAttribute("sesion") == null) {
			int numeroSesion = numberJuego.numeroRandom();
			sesion.setAttribute("sesion",numeroSesion);
		}
		else numeroAdivinado = (int) sesion.getAttribute("sesion");
		
		//Almaceno el numero en la sesion
		if(numeroIngresado == numeroAdivinado) {
			mensajeAdivina = numeroAdivinado+" was the number";
			mensajeOk = "Ok";
		}
		
		if(numeroIngresado > numeroAdivinado) {
			mensajeMayor = "Too high!";
			mensajeOk = "No";
		}
		if(numeroIngresado < numeroAdivinado) {
			mensajeMenor = "Too low!";
			mensajeOk = "No";
		}
		
		request.setAttribute("mensajeAdivina", mensajeAdivina);
		request.setAttribute("mensajeOk", mensajeOk);
		request.setAttribute("mensajeMayor", mensajeMayor);
		request.setAttribute("mensajeMenor", mensajeMenor);
		
		System.out.println(numeroAdivinado);
		
		RequestDispatcher rd = request.getRequestDispatcher("inicio.jsp");
		rd.forward(request, response);
		
	}

}
