package cl.empresa;

import cl.empresa.modelo.Gorila;

//Crear una clase GorillaTest, para instanciar al gorila y hacer que lance algo tres veces, coma bananos dos veces y trepe a un �rbol una vez.
public class GorilaTest {

	public static void main(String[] args) {
		Gorila gorila = new Gorila();
		gorila.throwSomething();
		gorila.throwSomething();
		gorila.throwSomething();
		gorila.eatBananas();
		gorila.eatBananas();
		gorila.climb();
	}
}