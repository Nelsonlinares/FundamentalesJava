package cl.empresa.modelo;

//Crear una clase Bat que tenga un m�todo fly(), eatHumans() y attackTown() y que tenga un nivel predeterminado de energ�a de 300.
public class Bat {
	private int energyLevel = 300;
	
	public Bat() {
		super();
	}

	public Bat(int energyLevel) {
		super();
		this.energyLevel = energyLevel;
	}

	public int getEnergyLevel() {
		return energyLevel;
	}

	public void setEnergyLevel(int energyLevel) {
		this.energyLevel = energyLevel;
	}

	@Override
	public String toString() {
		return "Bat [energyLevel=" + energyLevel + "]";
	}
	
	//Para el m�todo fly(), mostrar el sonido que hace el Bat al despegar y disminuir su nivel de energ�a en 50
	public void fly() {
		System.out.println("Despegando");
		setEnergyLevel(getEnergyLevel()-50);
	}
	
	//Para el m�todo eatHumans(), Imprimir �bueno, no importa� e incrementar su nivel de energ�a en 25.
	public void eatHumans() {
		System.out.println("Bueno, no importa");
		setEnergyLevel(getEnergyLevel()+25);
	}
	
	//Para el m�todo attackTown(), mostar en pantalla el sonido de la ciudad en llamas y disminuir su nivel de energ�a en 100.
	public void attackTown() {
		System.out.println("El Gorila ha lanzado algo");
		setEnergyLevel(getEnergyLevel()-100);
	}
	
}
