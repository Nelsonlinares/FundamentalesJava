package cl.empresa.modelo;

public class Mammal {
	private int energyLevel = 100;
	
	public Mammal() {
		super();
	}

	public Mammal(int energyLevel) {
		super();
		this.energyLevel = energyLevel;
	}

	
	public int getEnergyLevel() {
		return energyLevel;
	}

	public void setEnergyLevel(int energyLevel) {
		this.energyLevel = energyLevel;
	}

	@Override
	public String toString() {
		return "Mammal [energyLevel=" + energyLevel + "]";
	}

	//Crear una clase Mammal que tenga un energyLevel y un  m�todo desiplayEnergy(). El m�todo displayEnergy() debe imprimir el nivel de energ�a del animal y devolverlo.
	public int displayEnergy(){
		int energia = getEnergyLevel();
		System.out.println("El nivel de energ�a actual es: "+energia);
		return energia;
	}
	
}
