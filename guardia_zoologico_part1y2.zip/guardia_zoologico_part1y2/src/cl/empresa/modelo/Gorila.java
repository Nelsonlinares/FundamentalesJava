package cl.empresa.modelo;

public class Gorila {
	private int energyLevel = 100;
	
	public Gorila() {
		super();
	}
		
	public Gorila(int energyLevel) {
		super();
		this.energyLevel = energyLevel;
	}
	
	public int getEnergyLevel() {
		return energyLevel;
	}

	public void setEnergyLevel(int energyLevel) {
		this.energyLevel = energyLevel;
	}
	
	@Override
	public String toString() {
		return "Gorila [energyLevel=" + energyLevel + "]";
	}

	//Para el m�todo throwSomething(), hacer que imprima un mensaje en pantalla indicando que el gorila ha lanzado algo, al mismo tiempo que disminuye su nivel de energ�a en 5.
	public void throwSomething() {
		System.out.println("El Gorila ha lanzado algo");
		setEnergyLevel(getEnergyLevel()-5);
	}
	
	//Para el m�todo eatBananas(), hacer que imprima un mensaje en pantalla indicando la satisfacci�n del gorila e incrementar su nivel de energ�a en 10.
	public void eatBananas() {
		System.out.println("El Gorila est� satisfecho");
		setEnergyLevel(getEnergyLevel()+10);
	}
	
	//Para el m�todo climb(), hacer que muestre un mensaje en pantalla indicando que el gorila ha trepado a la cima de un �rbol y disminuir su nivel de energ�a en 10.
	public void climb() {
		System.out.println("El Gorila ha trepado a la cima de un �rbol");
		setEnergyLevel(getEnergyLevel()-10);
	}
	
}
