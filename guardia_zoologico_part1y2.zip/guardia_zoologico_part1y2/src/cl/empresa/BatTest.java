package cl.empresa;

import cl.empresa.modelo.Bat;

//Crear la clase BatTest para instanciar a Bat y hacer que ataque la ciudad tres veces, como dos humanos y vuele dos veces.
public class BatTest {

	public static void main(String[] args) {
		Bat bt = new Bat();
		bt.attackTown();
		bt.attackTown();
		bt.attackTown();
		bt.eatHumans();
		bt.eatHumans();
		bt.fly();
		bt.fly();
	}

}
